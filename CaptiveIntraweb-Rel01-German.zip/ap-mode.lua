 wifi.setmode(wifi.SOFTAP)
 cfg={}
     cfg.ssid="SpielMitMir"
     wifi.ap.config(cfg)
