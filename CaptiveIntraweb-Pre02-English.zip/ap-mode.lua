 wifi.setmode(wifi.SOFTAP)
 cfg={}
     cfg.ssid="PlayWithMe"
     wifi.ap.config(cfg)