dofile ("dns-liar.lua")
dofile ("server.lua")